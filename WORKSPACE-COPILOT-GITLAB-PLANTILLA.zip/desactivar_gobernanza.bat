@echo off
echo ========================================================
echo === DESACTIVANDO GOBERNANZA PILOTO (MARCHA ATRAS) ===
echo ========================================================
if exist .vscode (
    rename .vscode .vscode_desactivado
    echo [OK] Carpeta .vscode desactivada con exito.
)
if exist .github (
    rename .github .github_desactivado
    echo [OK] Carpeta .github desactivada con exito.
)
if exist .gitlab (
    rename .gitlab .gitlab_desactivado
    echo [OK] Carpeta .gitlab desactivada con exito.
)
echo ========================================================
echo Tu proyecto ha vuelto 100% al modo estandar de Copilot.
echo Puedes reabrir VS Code normalmente.
echo ========================================================
pause
