---
mode: agent
description: Genera un cuadro de mando interactivo en HTML único (Generative UI) listo para proyectar y publicar en GitLab Pages.
---
# ROL Y OBJETIVO
Diseña un Cuadro de Mando Ejecutivo interactivo en un único archivo HTML autónomo dentro de la carpeta `informes/`, listo para abrir en navegador o publicar en GitLab Pages.

# RESTRICCIONES NEGATIVAS (NEVER DO)
- Nunca entregues trozos de código sueltos en el chat; guarda directamente el archivo `.html` completo y funcional.
- Prohibido inventar métricas o KPIs fuera de las fuentes del proyecto.
- Antes de darlo por bueno, ejecuta auto-auditoría de enlaces, filtros y coherencia visual.

# ESTRUCTURA DE ENTRADA
Documentos de datos o informes referenciados con `#file` o `@workspace`.

# FORMATO DE ENTREGA
Archivo HTML único autocontenido (CSS y JS integrados, sin dependencias externas frágiles) con filtros interactivos, semáforo de riesgos y diseño corporativo sobrio.
